# Import Libraries
# Flask Libraries (used to run the actual website)
from flask import Flask, render_template, request, redirect, flash, session, url_for  # General Flask
from flask_wtf import FlaskForm  # For Flask forms
from flask_bcrypt import Bcrypt  # For encryption
# WTForms Libraries (used for the websites forms)
from wtforms import StringField, SubmitField, EmailField, PasswordField, SelectMultipleField, validators
# Miscellaneous Libraries
import sqlite3  # To connect and run query's for the database
import requests  # To request and download data from APIs
import json  # Required to be able to view and manage the json files and format
from apscheduler.schedulers.background import \
    BackgroundScheduler  # Used to run the get data and clear data functions every 30 minutes
import atexit  # Used for scheduler to shut down the schedules when the app is exited
from datetime import date, timedelta  # For getting the current or future datetime


# TODO
#   Signup page check if email already exists is broken due to the encryption of the email find a fix!!!
#   Incorporate index page map with search function
#   My username will be unique + Password and email will be encrypted (add to documentation)
#   Is there a better way to convert my json to sql? (Don't think so)
#   Finish search page (Decide to either to use get search method or javascript)
#   Work on data page with a data visualizer
#   Add change email or password for / user page
#   Make the website look nice


# Assign flask app
app = Flask(__name__)


# Assign Bcrypt
bcrypt = Bcrypt(app)

# Security Key
app.config['SECRET_KEY'] = 'MY_SECRET_KEY'  # Due to this being a prototype a secret key won't be created (IT WILL BE!)

# Connect database
con = sqlite3.connect('system.db', check_same_thread=False)  # connect to the websites database
cur = con.cursor()  # Set cur to equal the database cursor


# Form models
class NoValSelectMultipleField(SelectMultipleField):
    def pre_validate(self, form):
        """per_validation is disabled"""
    # Due to a known bug for pre validation with select multiple fields in wtforms
    # this work around has been advised by developers of wtforms


class LoginForm(FlaskForm):
    # Username
    username = StringField('Username:', validators=[validators.DataRequired()])
    # # Email
    # email = EmailField('Email:', validators=[validators.DataRequired(), validators.Email()])
    # Password
    password = PasswordField('Password:', validators=[validators.DataRequired()])
    # Login form with a submit button which isn't required but added for user ability
    submit = SubmitField('Log In!')


class SignUp(FlaskForm):
    # Username
    username = StringField('Username:', validators=[validators.DataRequired(), validators.Length(3, 12, "The username must be 3 characters min and 12 characters max")])
    # Password with a confirmation password
    password = PasswordField('Password:', validators=[validators.DataRequired(), validators.Length(3, 64, "The password must be 3 characters min and 64 characters max"), validators.EqualTo('password_confirmation', message='Passwords must match')])
    password_confirmation = PasswordField('Repeat Password', validators=[validators.DataRequired(), validators.Length(3, 64, "The password must be 3 characters min and 64 characters max"), validators.EqualTo('password', message='Passwords must match')])
    # Email has email validator and has a confirmation field
    email = EmailField('Email:', validators=[validators.DataRequired(), validators.Email(), validators.EqualTo('email_confirmation', message='Emails must match')])
    email_confirmation = EmailField('Repeat Email:', validators=[validators.DataRequired(), validators.Email(), validators.EqualTo('email', message='Emails must match')])
    # Sign up form with a submit button which isn't required but added for user ability
    submit = SubmitField('Create an Account!')


# Functions
def getData():
    # Print to console
    print(date.today(), " Getting Data!")

    # Download, convert and merge trucks json to sql
    try:
        trucks_page = requests.get(
            "https://www.bnefoodtrucks.com.au/api/1/trucks")  # Replaces url everytime the function is called to make sure the url isnt changed
        trucks_json = json.loads(trucks_page.text)  # Convert page to readable json / dict format
        for truck in trucks_json:  # For every element in the json file
            # Do not use MURGE because of ...
            cur.execute(
                """INSERT OR REPLACE INTO trucks(truck_id, name, category, bio, avatar_src,avatar_alt,avatar_title,cover_photo_src, cover_photo_alt, cover_photo_title, website, facebook_url, instagram_handle, twitter_handle)VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (truck.get('truck_id'), truck.get('name'), truck.get('category'), truck.get('bio'),
                 str(truck['avatar']['src'] if truck['avatar'] != "" else ""), truck.get('name'),
                 truck.get('name'), str(truck['cover_photo']['src'] if truck['cover_photo'] != "" else ""),
                 # Avater photo alt and title replaced with name of truck
                 truck.get('name'), truck.get('name'),  # Cover photo alt and title replaced with name of truck
                 truck.get('website'), truck.get('facebook_url'), truck.get('instagram_handle'), truck.get(
                    'twitter_handle'),))  # use .get instead of data[''] as if the value doesnt exists it will return null. Have to convert the json for the images to string before parsing it to prevent errors in the future.
        con.commit()  # Commit changes to the table after for loop is complete.
    except Exception as e:  # If an error occurs print the error code and an error message.
        print(e)
        print("Error: Could not download or convert trucks database")

    # Download, convert and merge sites json to sql
    try:
        sites_page = requests.get(
            "https://www.bnefoodtrucks.com.au/api/1/sites")  # Replaces url everytime the function is called to make sure the url isnt changed
        sites_json = json.loads(sites_page.text)  # Convert page to readable json / dict format
        for site in sites_json:  # For every element in the json file
            # Do not use MURGE because of ...
            cur.execute(
                """INSERT OR REPLACE INTO sites(site_id, title, description, street, suburb, state, postcode, country, latitude, longitude, spots, cost, image_src, image_alt, image_title, map_src, map_alt, map_title) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    site.get('site_id'), site.get('title'), site.get('description'), site.get('street'),
                    site.get('suburb'),
                    site.get('state'), site.get('postcode'), site.get('country'), site.get('latitude'),
                    site.get('longitude'),
                    site.get('spots'), site.get('cost'), str(site['image']['src'] if site['image'] != "" else ""),
                    site.get('title'), site.get('title'),
                    str(site['map']['src'] if site['map'] != "" else ""), (
                                str(site.get('street')) + ", " + str(site.get('suburb')) + ", " + str(
                            site.get('state')) + ", " + str(site.get('postcode')) + ", " + str(site.get('country'))),
                    (str(site.get('street')) + ", " + str(site.get('suburb')) + ", " + str(
                        site.get('state')) + ", " + str(site.get('postcode')) + ", " + str(
                        site.get('country'))),))  # replaced map and image alt and title with custom values

        con.commit()  # Commit changes to the table after for loop is complete.
    except Exception as e:  # If an error occurs print the error code and an error message.
        print(e)
        print("Error: Could not download or convert sites database")

    # Download, convert and merge bookings json to sql
    try:
        bookings_page = requests.get(
            "https://www.bnefoodtrucks.com.au/api/1/bookings")  # Replaces url everytime the function is called to make sure the url isnt changed
        bookings_json = json.loads(bookings_page.text)  # Convert page to readable json / dict format
        for booking in bookings_json:  # For every element in the json file
            # Do not use MURGE because of ...
            cur.execute(
                """INSERT OR REPLACE INTO bookings(title, truck_id, site_id, start, finish)VALUES (?,?,?,?,?)""", (
                booking.get('title'), booking.get('truck_id'), booking.get('site_id'), booking.get('start'),
                booking.get('finish'),))
        con.commit()  # Commit changes to the table after for loop is complete.
    except Exception as e:  # If an error occurs print the error code and an error message.
        print(e)
        print("Error: Could not download or convert bookings database")


def cleanData():
    # Will clean the database of old files to make sure the db runs smoothly
    print('nothin yet')


def getBookings(time, time2):
    # Get Bookings
    sql_bookings = """
        SELECT *
        FROM sites s, bookings b, trucks t
        WHERE s.site_id = b.site_id
        AND b.truck_id = t.truck_id
        AND b.finish > (?)
        AND b.finish < (?);"""
    cur.execute(sql_bookings, (time, time2,))
    results_bookings = cur.fetchall()

    # Abandoned geojson concept for string location data
    # geo_json_list = []
    # for booking in results_bookings:
    #     # code to generate your geoJSON
    #     crood = Point((booking[9],booking[8]))
    #     point = Feature(geometry=crood, properties={"name": "test1", "amenity": "test2", "popupContent": "test3"})
    #     geo_json_list.append(point)
    # with open('static/jsons/geodata.json', 'a') as f:
    #     json.dump(geo_json_list, f, indent=4)

    return (results_bookings)


def getTrucks():
    # Get Trucks
    sql_trucks = """
        SELECT *
        FROM trucks;"""
    cur.execute(sql_trucks)
    results_trucks = cur.fetchall()

    return (results_trucks)


def loginReturn(form):
    if form.validate_on_submit():
        # Set email and password variables
        un = form.username.data
        pw = form.password.data

        # Check users if the combination of username and password exists
        sql_user = """
                        select *
                        from users 
                        where username = ?;"""
        cur.execute(sql_user, (un,))
        result_user = cur.fetchall()

        # If a user with that username and password combination exists set session values with the users data
        if len(result_user) == 1 and bcrypt.check_password_hash(result_user[0][2], pw):
            flash(str(result_user[0][1]) + " has successfully logged in!", 'message')
            session['user_id'] = result_user[0][0]
            session['username'] = result_user[0][1]
        else:
            flash("Username or password incorrect!", 'error')
    else:
        flash("There is something missing!", 'error')


def signupReturn(form):
    if form.validate_on_submit():
        # Set username, password and email variables
        un = form.username.data
        em = form.email.data
        pw = form.password.data

        try:
            # Check users if the email already exists
            sql_user = """
                            select *
                            from users
                            where username = ?;"""
            cur.execute(sql_user, (un,))
            if (len(cur.fetchall()) >= 1):
                # If an account already exists with the inputted username flash an error
                flash("An account with that username already exists!", 'error')
                return None

            # Check users if the email already exists
            # No longer WORKS due to email being encrypted FIX THIS!!!
            sql_user = """
                            select *
                            from users
                            where email = ?;"""
            cur.execute(sql_user, (em,))
            if (len(cur.fetchall()) >= 1):
                # If an account already exists with the inputted email flash an error
                flash("An account with that email already exists!", 'error')
                return None

            try:
                # Encrypt Password
                pw_hash = bcrypt.generate_password_hash(pw)
                # Encrypt Email
                em_hash = bcrypt.generate_password_hash(em)

                # Insert new user into database with encrypted password and email
                cur.execute("INSERT INTO users(username,password,email) VALUES (?,?,?)", (un, pw_hash, em_hash,))
                con.commit()

                # Flash success message
                flash(un + " has successfully created an account!", 'message')

                # Attempt login
                loginReturn(form)
            except Exception as e:  # If an error occurs print the error code and an error message.
                print(e)
                print("Error: Could not upload account to database!", 'error')
                # Flash error message
                flash("An error occurred and the account could not be created! Please try again later.", 'error')
        except Exception as e:  # If an error occurs print the error code and an error message.
            print(e)
            print("Error: Account already existed!")
            # Flash error message
            flash("Please try again.", 'error')
    else:
        flash("There is something missing!", 'error')


# Schedules
schedule_0 = BackgroundScheduler()  # Sets up the background scheduler
schedule_0.add_job(func=getData, trigger='interval', minutes=30)  # Sets getData function to run every 30 minutes
schedule_0.start()  # Starts the schedules
atexit.register(lambda: schedule_0.shutdown())  # Sets up the schedular to shut down when the app is exited


# Routes
@app.route('/', methods=['GET', 'POST'])
@app.route('/index', methods=['GET', 'POST'])
def index():
    # Set Login Form
    loginform = LoginForm()
    # If the page request method is POST
    if request.method == 'POST':
        # Contacts the loginReturn function which will check if the user exists and logs in and or return a flash msg
        loginReturn(loginform)

    bookings = getBookings(date.today(), (date.today() + timedelta(days=1)))
    trucks = getTrucks()
    return render_template('index.html', title='Food Trucks', loginform=loginform, bookings=bookings, trucks=trucks)


@app.route('/logout', methods=['GET'])
def logout():
    # clear out the session
    if session.get('user_id'):
        session['user_id'] = None
        session['username'] = None
        flash("You have successfully logged out", 'message')
    else:
        flash("You have to be logged in to do that!", 'error')
    return redirect(url_for('index'))


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    # If user is already logged in flash a message and redirect them back to the index page
    if session.get('user_id'):
        flash("You are already logged in!", 'error')
        return redirect(url_for('index'))

    # Set SignUp Form
    signup_form = SignUp()
    # Set Login Form
    login_form = LoginForm()

    # If the page request method is POST
    if request.method == 'POST':
        if signup_form.validate():
            # Contacts the signupReturn function which will check the data returned and create an account and or return a flash msg
            signupReturn(signup_form)
        else:
            # Contacts the loginReturn function which will check if the user exists and logs in and or return a flash msg
            loginReturn(login_form)

    return render_template('signup.html', title='Create an account!', loginform=login_form, form=signup_form)


@app.route('/search', methods=['GET', 'POST'])
def search():
    # Set Login Form
    loginform = LoginForm()
    # If the page request method is POST
    if request.method == 'POST':
        # Contacts the loginReturn function which will check if the user exists and logs in and or return a flash msg
        loginReturn(loginform)

    # Abounded get request search method
    # if request.args.get('q'):
    #     name = request.args.get('q')
    #     flash(name)
    # if request.args.get('t'):
    #     types = request.args.get('t')
    #     flash(types)

    trucks = getTrucks()

    return render_template('search.html', title='Search Trucks!', loginform=loginform, trucks=trucks)


# Website Startup
if __name__ == '__main__':
    # Start App
    port = 7250  # Port to be hosted on
    app.run('', 7250, debug=True)  # Run the app
